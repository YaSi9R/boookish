import React from 'react'

const Error = () => {
  return (
    <div>
      <h1 className='h-10 w-10 bg-yellow-25 text-white '>Error in the page</h1>
      
    </div>
    
  )
}

export default Error
