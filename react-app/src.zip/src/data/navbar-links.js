




export const CompetitiveDropdown = [
  { name: "CAT/GATE/GRE BOOKS", path: "/usedBooks/catgrebooks " },
  { name: "ENGINEERING BOOKS", path: "/usedBooks/engineeringexambooks" },
  { name: "NEET/AIIMS BOOKS", path: "/usedBooks/neetaiimsbooks" },
  { name: "UPSC BOOKS", path: "/usedBooks/upscbooks" },


];

export const serviceDropdown = [
  { name: "SCHOOL BOOKS", path: "/competitivebooks/schoolbooks" },
  { name: "COLLEGE BOOKS", path: "/competitivebooks/collegebooks" },
  { name: "MEDICAL", path: "/competitivebooks/medical" },
  { name: "ENGINEERING", path: "/competitivebooks/engineering" },
  { name: "OTHERS", path: "/competitivebooks/others" },



];
export const novelDropdown = [
  { name: "Fiction", path: "/novelbooks/fiction" },
  { name: "Non-Fiction", path: "/novelbooks/nonfiction" },


]